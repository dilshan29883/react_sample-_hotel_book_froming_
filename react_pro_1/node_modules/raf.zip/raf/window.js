try {
  module.exports = window
} catch(e) {
  module.exports = {}
}
