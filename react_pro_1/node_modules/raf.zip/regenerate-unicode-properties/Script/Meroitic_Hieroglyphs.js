const set = require('regenerate')();
set.addRange(0x10980, 0x1099F);
exports.characters = set;
