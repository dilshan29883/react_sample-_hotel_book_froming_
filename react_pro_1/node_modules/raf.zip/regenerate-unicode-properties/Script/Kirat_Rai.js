const set = require('regenerate')();
set.addRange(0x16D40, 0x16D79);
exports.characters = set;
