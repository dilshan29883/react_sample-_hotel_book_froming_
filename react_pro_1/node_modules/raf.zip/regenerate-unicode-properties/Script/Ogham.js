const set = require('regenerate')();
set.addRange(0x1680, 0x169C);
exports.characters = set;
