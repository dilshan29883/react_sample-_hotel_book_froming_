const set = require('regenerate')();
set.addRange(0x10400, 0x1044F);
exports.characters = set;
