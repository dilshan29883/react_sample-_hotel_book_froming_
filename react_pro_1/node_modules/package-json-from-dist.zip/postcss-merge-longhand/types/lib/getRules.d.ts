declare function _exports(props: import('postcss').Declaration[], properties: string[]): import('postcss').Declaration[];
export = _exports;
