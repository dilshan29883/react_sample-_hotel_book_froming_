declare function intersect<T>(arrayA?: T[], arrayB?: T[]): T[];
export default intersect;
