export default function decodeCodePoint(codePoint: number): string;
//# sourceMappingURL=decode_codepoint.d.ts.map