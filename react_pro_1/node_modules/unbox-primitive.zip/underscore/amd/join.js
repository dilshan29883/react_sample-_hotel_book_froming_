define(['./_unmethodize', './_setup'], function (_unmethodize, _setup) {

	var join = _unmethodize(_setup.ArrayProto.join);

	return join;

});
