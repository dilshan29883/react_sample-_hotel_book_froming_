define(function () {

  function strictEqual(left, right) {
    return left === right;
  }

  return strictEqual;

});
