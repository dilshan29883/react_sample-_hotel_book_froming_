// Internal `_.pick` helper function to determine whether `key` is an enumerable
// property name of `obj`.
export default function keyInObj(value, key, obj) {
  return key in obj;
}
