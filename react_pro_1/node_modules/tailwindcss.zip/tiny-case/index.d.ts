export function words(str: string): string[]

export function upperFirst(str: string): string

export function camelCase(str: string): string

export function pascalCase(str: string): string

export function snakeCase(str: string): string

export function kebabCase(str: string): string

export function sentenceCase(str: string): string

export function titleCase(str: string): string
