var get = require("./get.js");
var getPrototypeOf = require("./getPrototypeOf.js");
function _superPropertyGet(t, e, o, r) {
  var p = get(getPrototypeOf(1 & r ? t.prototype : t), e, o);
  return 2 & r && "function" == typeof p ? function (t) {
    return p.apply(o, t);
  } : p;
}
module.exports = _superPropertyGet, module.exports.__esModule = true, module.exports["default"] = module.exports;