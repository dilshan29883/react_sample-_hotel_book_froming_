# @babel/plugin-transform-parameters

> Compile ES2015 default and rest parameters to ES5

See our website [@babel/plugin-transform-parameters](https://babeljs.io/docs/babel-plugin-transform-parameters) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-parameters
```

or using yarn:

```sh
yarn add @babel/plugin-transform-parameters --dev
```
