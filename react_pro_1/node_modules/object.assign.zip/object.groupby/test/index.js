'use strict';

var test = require('tape');

var index = require('../');
var runTests = require('./tests');

test('as a function', function (t) {
	runTests(index, t);

	t.end();
});
