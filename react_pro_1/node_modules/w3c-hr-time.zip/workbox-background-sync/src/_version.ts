// @ts-ignore
try{self['workbox:background-sync:6.6.0']&&_()}catch(e){}