module.exports = require('./dist/types').Pair
require('./dist/legacy-exports').warnFileDeprecation(__filename)
