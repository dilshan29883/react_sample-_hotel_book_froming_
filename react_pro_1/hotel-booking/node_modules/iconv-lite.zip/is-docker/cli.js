#!/usr/bin/env node
'use strict';
const isDocker = require('.');

process.exitCode = isDocker() ? 0 : 2;
