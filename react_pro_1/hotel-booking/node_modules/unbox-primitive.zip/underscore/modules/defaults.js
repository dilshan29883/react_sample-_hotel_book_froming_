import createAssigner from './_createAssigner.js';
import allKeys from './allKeys.js';

// Fill in a given object with default properties.
export default createAssigner(allKeys, true);
