define(['exports', './concat', './join', './slice'], function (exports, concat, join, slice) {



	exports.concat = concat;
	exports.join = join;
	exports.slice = slice;

	Object.defineProperty(exports, '__esModule', { value: true });

});
