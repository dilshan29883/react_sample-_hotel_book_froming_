define(['./_createReduce'], function (_createReduce) {

	// The right-associative version of reduce, also known as `foldr`.
	var reduceRight = _createReduce(-1);

	return reduceRight;

});
