const set = require('regenerate')();
set.addRange(0x105C0, 0x105F3);
exports.characters = set;
