const set = require('regenerate')();
set.addRange(0x16AD0, 0x16AED).addRange(0x16AF0, 0x16AF5);
exports.characters = set;
