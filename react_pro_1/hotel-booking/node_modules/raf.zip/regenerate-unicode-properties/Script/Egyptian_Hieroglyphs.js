const set = require('regenerate')();
set.addRange(0x13000, 0x13455).addRange(0x13460, 0x143FA);
exports.characters = set;
