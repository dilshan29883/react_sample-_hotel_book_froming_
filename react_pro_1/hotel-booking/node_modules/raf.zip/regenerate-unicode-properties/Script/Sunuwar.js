const set = require('regenerate')();
set.addRange(0x11BC0, 0x11BE1).addRange(0x11BF0, 0x11BF9);
exports.characters = set;
