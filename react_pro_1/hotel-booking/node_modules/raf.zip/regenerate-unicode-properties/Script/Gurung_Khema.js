const set = require('regenerate')();
set.addRange(0x16100, 0x16139);
exports.characters = set;
