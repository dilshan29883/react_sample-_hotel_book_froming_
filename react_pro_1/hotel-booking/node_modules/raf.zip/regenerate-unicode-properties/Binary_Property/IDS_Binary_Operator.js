const set = require('regenerate')(0x31EF);
set.addRange(0x2FF0, 0x2FF1).addRange(0x2FF4, 0x2FFD);
exports.characters = set;
