const set = require('regenerate')(0xB7, 0x305);
set.addRange(0x10500, 0x10527);
exports.characters = set;
