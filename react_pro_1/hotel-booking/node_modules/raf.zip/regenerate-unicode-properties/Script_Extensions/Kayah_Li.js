const set = require('regenerate')();
set.addRange(0xA900, 0xA92F);
exports.characters = set;
