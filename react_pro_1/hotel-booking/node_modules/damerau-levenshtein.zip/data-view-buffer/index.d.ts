declare function dataViewBuffer(value: DataView): ArrayBuffer;
declare function dataViewBuffer(value: unknown): never;

export = dataViewBuffer;