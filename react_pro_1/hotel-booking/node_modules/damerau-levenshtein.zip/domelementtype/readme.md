All the types of nodes in htmlparser2's DOM.
