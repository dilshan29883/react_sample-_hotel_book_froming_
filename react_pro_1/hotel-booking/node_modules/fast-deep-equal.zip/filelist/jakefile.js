testTask('FileList', function () {
  this.testFiles.include('test/*.js');
});

publishTask('FileList', function () {
  this.packageFiles.include([
  'jakefile.js',
  'README.md',
  'package.json',
  'index.js',
  'index.d.ts'
  ]);
});


