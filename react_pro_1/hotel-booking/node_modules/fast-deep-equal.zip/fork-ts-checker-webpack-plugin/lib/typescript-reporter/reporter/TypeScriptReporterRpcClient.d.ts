import { TypeScriptReporterConfiguration } from '../TypeScriptReporterConfiguration';
import { ReporterRpcClient } from '../../reporter';
declare function createTypeScriptReporterRpcClient(configuration: TypeScriptReporterConfiguration): ReporterRpcClient;
export { createTypeScriptReporterRpcClient };
