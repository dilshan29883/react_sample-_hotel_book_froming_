declare type TypeScriptVueExtensionOptions = boolean | {
    enabled?: boolean;
    compiler?: string;
};
export { TypeScriptVueExtensionOptions };
