declare function hasToStringTagShams(): boolean;

export = hasToStringTagShams;
