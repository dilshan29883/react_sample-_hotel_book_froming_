/*! https://mths.be/includes v2.0.0 by @mathias */

'use strict';

var implementation = require('./implementation');

module.exports = function getPolyfill() {
	return String.prototype.includes || implementation;
};
