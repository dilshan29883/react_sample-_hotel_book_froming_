export = MediaSlash9;
declare class MediaSlash9 extends BasePlugin {
    /** @param {import('postcss').Result} result */
    constructor(result: import('postcss').Result);
    /**
     * @param {import('postcss').AtRule} rule
     * @return {void}
     */
    detect(rule: import('postcss').AtRule): void;
}
import BasePlugin = require("../plugin");
