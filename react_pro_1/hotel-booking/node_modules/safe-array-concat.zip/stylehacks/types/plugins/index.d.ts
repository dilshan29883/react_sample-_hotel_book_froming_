declare const _exports: ({
    new (result?: import("postcss").Result | undefined): important;
} | {
    new (result?: import("postcss").Result | undefined): trailingSlashComma;
})[];
export = _exports;
