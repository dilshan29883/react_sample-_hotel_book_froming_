import '../_version.js';
/**
 * A utility function that determines whether the current browser supports
 * constructing a new `Response` from a `response.body` stream.
 *
 * @return {boolean} `true`, if the current browser can successfully
 *     construct a `Response` from a `response.body` stream, `false` otherwise.
 *
 * @private
 */
declare function canConstructResponseFromBodyStream(): boolean;
export { canConstructResponseFromBodyStream };
