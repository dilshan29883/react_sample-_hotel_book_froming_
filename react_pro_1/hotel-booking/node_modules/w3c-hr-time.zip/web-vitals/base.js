// Creates the `web-vitals/base` import in node-based bundlers.
// This will not be needed when export maps are widely supported.
export * from './dist/web-vitals.base.js';
