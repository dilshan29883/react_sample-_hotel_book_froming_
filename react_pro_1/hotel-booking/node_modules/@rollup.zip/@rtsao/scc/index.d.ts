export default function tarjan<T>(graph: Map<T, Set<T>>): Array<Set<T>>
