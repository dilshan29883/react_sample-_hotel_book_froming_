export {};
//# sourceMappingURL=custom-config-package-names.d.ts.map