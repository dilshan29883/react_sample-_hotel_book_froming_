export declare function findAndConsoleLogPatchPathCli(): void;
export declare function getPathToLinterJS(): string;
export declare function ensurePathToGeneratedPatch(): string;
//# sourceMappingURL=path-utils.d.ts.map