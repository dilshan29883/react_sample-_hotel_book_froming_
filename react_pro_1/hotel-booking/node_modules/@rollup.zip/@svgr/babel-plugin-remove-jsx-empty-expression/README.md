# @svgr/babel-plugin-remove-jsx-empty-expression

## Install

```
npm install --save-dev @svgr/babel-plugin-remove-jsx-empty-expression
```

## Usage

**.babelrc**

```json
{
  "plugins": ["@svgr/babel-plugin-remove-jsx-empty-expression"]
}
```

## License

MIT
