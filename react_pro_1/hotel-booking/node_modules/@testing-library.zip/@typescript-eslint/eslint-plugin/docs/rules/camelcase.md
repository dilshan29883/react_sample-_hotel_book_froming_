:::danger Deprecated

This rule has been deprecated in favour of the [`naming-convention`](./naming-convention.md) rule.

:::

<!--
This doc file has been left on purpose because `camelcase` is a core eslint rule.
This exists to help direct people to the replacement rule.
-->
