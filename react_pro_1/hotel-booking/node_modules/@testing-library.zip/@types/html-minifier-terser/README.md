# Installation
> `npm install --save @types/html-minifier-terser`

# Summary
This package contains type definitions for html-minifier-terser (https://github.com/terser/html-minifier-terser#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/html-minifier-terser.

### Additional Details
 * Last updated: Tue, 23 Nov 2021 21:01:04 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Piotr Błażejewicz](https://github.com/peterblazejewicz).
