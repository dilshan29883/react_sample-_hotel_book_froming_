import { JSONHydrator } from './postcss.js'

interface FromJSON extends JSONHydrator {
  default: FromJSON
}

declare const fromJSON: FromJSON

export = fromJSON
