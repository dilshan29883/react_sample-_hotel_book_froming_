declare function _exports(input: string): [number, number, number][];
export = _exports;
