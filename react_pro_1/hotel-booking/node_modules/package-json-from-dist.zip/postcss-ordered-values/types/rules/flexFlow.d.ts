declare function _exports(flexFlow: import('postcss-value-parser').ParsedValue): string;
export = _exports;
