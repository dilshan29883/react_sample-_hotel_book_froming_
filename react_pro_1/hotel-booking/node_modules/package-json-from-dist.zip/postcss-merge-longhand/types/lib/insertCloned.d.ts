declare function _exports(rule: import('postcss').Rule, decl: import('postcss').Declaration, props?: Partial<import('postcss').DeclarationProps> | undefined): import('postcss').Declaration;
export = _exports;
