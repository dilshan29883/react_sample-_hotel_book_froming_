declare function _exports(prop: string): {
    explode: (rule: import('postcss').Rule) => void;
    merge: (rule: import('postcss').Rule) => void;
};
export = _exports;
