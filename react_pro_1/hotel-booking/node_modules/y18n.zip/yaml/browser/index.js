module.exports = require('./dist').YAML
