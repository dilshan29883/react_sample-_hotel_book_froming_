'use strict';

var getGlobal = require('globalthis/polyfill');

// https://262.ecma-international.org/6.0/#sec-getglobalobject

module.exports = function GetGlobalObject() {
	return getGlobal();
};
